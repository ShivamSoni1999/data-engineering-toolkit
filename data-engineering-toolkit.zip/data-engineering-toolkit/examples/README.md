# Examples

The example pipeline demonstrates a small configuration-driven quality workflow. It intentionally uses local in-memory rows so it can run without cloud credentials.
